Royston-Sauerbrei book: Instructions on how to use the Stata materials.
-----------------------------------------------------------------------

Version 1.1, 2008jul02

Note that these instructions apply to Stata for Windows only.

The materials are contained in two zip files: rsbook_stata_web.zip and rsbook_ado.zip. The examples are best run using Stata 10, although the vast majority will work fine with Stata 9.2.

rsbook_stata_web.zip comprises a folder containing Stata .do files for each of chapters 1 through 6, and parts of chapters 7 and 11 (\chap1, \chap2, ...), a folder (\data) containing the data files (see note 1 below) and an empty folder (\output) to contain log files and graph files created by running the examples.

rsbook_ado.zip contains all the required ado-files (Stata programs) for the examples. Most of these have help files that you can read in Stata (i.e. help <progname>).

To run the examples, do the following:

1. On your computer, make a folder to hold the book materials (e.g. c:\rsbook - the assumed default). We will suppose for the purposes of these instructions that the folder is called c:\rsbook, although you can use any pathname acceptable to Windows.

2. Start Stata and issue the command "sysdir". A typical example is as follows:

. sysdir
   STATA:  C:\Program Files\Stata10\
 UPDATES:  C:\Program Files\Stata10\ado\updates\
    BASE:  C:\Program Files\Stata10\ado\base\
    SITE:  C:\Program Files\Stata10\ado\site\
    PLUS:  c:\ado\stbplus\
PERSONAL:  c:\ado\personal\
OLDPLACE:  c:\ado\

Note the folder labelled PERSONAL - here, it is called "c:\ado\personal\". Check on your computer if this folder and its "parent" (here, c:\ado) exist. If they don't exist, please create them.

3. From the book's website, download rsbook_stata_web.zip and rsbook_ado.zip to c:\rsbook (or to the book folder you wish to use).

4. Extract rsbook_stata.zip to c:\rsbook (or to the book folder you wish to use).

5. Extract rsbook_ado.zip to c:\ado\personal (or to the folder labelled PERSONAL reported by Stata's -sysdir-).

6. Using a plain text editor such as Notepad, edit the file mvmb_profile.ado which you will find in c:\ado\personal (or in the PERSONAL folder reported by Stata's -sysdir-). Change line 24 to read

local BOOKDIR "c:\rsbook"

or to give the pathname of the folder you wish to use for the book, if that isn't c:\rsbook.

7. In Stata, navigate to c:\rsbook by typing cd "c:\rsbook" (or navigate similarly to your preferred folder for the book).

8. Test your installation by typing

. do rsbook_test

This file should run without any error messages. If not, check that you have entered BOOKDIR correctly in mvmb_profile.ado, and that you have extracted rsbook_stata_web.zip correctly.

9. To run an example, say ch1_f01.do in chapter 1 to recreate figure 1.1, navigate in Stata to chap1 (e.g. type cd chap1) and then type do ch1_f01. If all is well, the example should run and create graph files (.gph for Stata graph files, .eps for encapsulated Postscript files, .emf for Windows enhanced metafiles) representing figure 1.1 (see page 3 of the book) in the folder c:\rsbook\output (or in the subfolder \output of your preferred folder for the book). Similarly, if the example produces data for a table, a log file in plain text format with the extension ".sto" will be created in the c:\rsbook\output folder.

10. If you wish, you may now delete the files rsbook_stata_web.zip and rsbook_ado.zip.


Important notes
===============

1. Examples
-----------
We have provided Stata programs for many of the figures and tables relating to modelling with FP, MFP and MFPI. This will enable you to reproduce a substantial number of the analyses on your own computer.

2. Datafiles
------------
Currently, a few of the data sets used in the book are unavailable. Nevertheless, the do-files are still included where relevant.

3. Support
----------
Where possible, we will respond to queries arising from your use of the programs or about MFP in general. However, please understand that we may not be able to reply to every single query.

